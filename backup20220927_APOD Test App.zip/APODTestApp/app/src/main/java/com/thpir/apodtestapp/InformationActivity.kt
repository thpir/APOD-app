package com.thpir.apodtestapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide

class InformationActivity : AppCompatActivity() {

    private lateinit var imageviewApod: ImageView
    private lateinit var textviewTitle: TextView
    private lateinit var textviewDate: TextView
    private lateinit var textviewDescription: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_information)

        val apodUrl = intent.getStringExtra("url")
        val apodTitleText= intent.getStringExtra("title")
        val apodDateText = intent.getStringExtra("date")
        val apodDescriptionText = intent.getStringExtra("description")
        val apodMediaType = intent.getStringExtra("type")

        imageviewApod = findViewById(R.id.imageviewApod)
        textviewTitle = findViewById(R.id.textviewTitle)
        textviewDate = findViewById(R.id.textviewDate)
        textviewDescription = findViewById(R.id.textviewDescription)

        Glide.with(this)
            .asDrawable()
            .load(apodUrl)
            .into(imageviewApod)
        textviewTitle.text = apodTitleText
        textviewDate.text = apodDateText
        textviewDescription.text = apodDescriptionText
    }
}